import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  projects = [];
  constructor(private fb: FormBuilder, private router: Router, private toastr: ToastrService) { }
  formdata;
  form: FormGroup;
  roles = [
    { value: 'Program Manager', viewValue: 'Program Manager' },
    { value: 'Developer', viewValue: 'Developer' },
  ];
  managerProjects = [
    { value: 'Smart Store', viewValue: 'Smart Store' },
    { value: 'Connected Container', viewValue: 'Connected Container' },
    { value: 'Digital Seer', viewValue: 'Digital Seer' }
  ]
  devProjects = [
    { value: 'Smart Store', viewValue: 'Smart Store' },
    { value: 'Connected Container', viewValue: 'Connected Container' }
  ]

  ngOnInit() {
    localStorage.removeItem('appName');
    this.form = this.fb.group({
      userName: ['', Validators.required],
      password: ['', Validators.required],
      role: ['', Validators.required],
      project: ['', Validators.required]
    });
  }

  onRoleSelect(selectedRole) {
    console.log('selected Role..', selectedRole);
    if (selectedRole === 'Program Manager') {
      this.projects = this.managerProjects;
    }
    else if (selectedRole === 'Developer') {
      this.projects = this.devProjects
    }
  }

  login(data) {
    if(this.form.valid){
      console.log('login..', data);
      if (data.userName === 'Admin' && data.password === 'admin') {
        if (data.role === 'Developer') {
          localStorage.setItem('appName', data.project);
          this.router.navigate(['/dashboard']);
          this.toastr.success('Login Successfully!!!');
        } else if (data.role === 'Program Manager') {
          localStorage.setItem('appName', data.project);
          this.router.navigate(['/dashboard']);
          this.toastr.success('Login Successfully!!!');
        }
      }
    } else {
      this.toastr.error('Please enter valid credentials!!!');
      this.router.navigate(['/login']);
    }
    
  }
}
