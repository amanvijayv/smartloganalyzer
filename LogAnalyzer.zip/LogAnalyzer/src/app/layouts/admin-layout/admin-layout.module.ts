import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { LbdModule } from '../../lbd/lbd.module';
import { NguiMapModule} from '@ngui/map';

import { AdminLayoutRoutes } from './admin-layout.routing';

import { HomeComponent } from '../../home/home.component';
import { UserComponent } from '../../user/user.component';
import { StackedcolumnchartComponent } from '../../stackedcolumnchart/stackedcolumnchart.component';
import { ChartModule, HIGHCHARTS_MODULES } from 'angular-highcharts';
import { MatTableModule, MatSortModule } from '@angular/material';
import { MatPaginatorModule, MatInputModule } from '@angular/material'; 
import { DataserviceService } from '../../service/dataservice.service';
import { HttpClientModule } from '@angular/common/http';
import { PiechartComponent } from '../../piechart/piechart.component';



@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    LbdModule,
    ChartModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    HttpClientModule,
    MatInputModule,    
    NguiMapModule.forRoot({apiUrl: 'https://maps.google.com/maps/api/js?key=YOUR_KEY_HERE'})
  ],
  declarations: [
    HomeComponent,
    UserComponent,
    StackedcolumnchartComponent,
    PiechartComponent
  ],
  providers: [DataserviceService, DatePipe]
})

export class AdminLayoutModule {}
