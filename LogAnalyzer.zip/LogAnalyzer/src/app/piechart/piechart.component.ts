import { Component, OnInit, OnDestroy } from '@angular/core';
import { Chart } from 'angular-highcharts';
import * as Highcharts from 'highcharts';
import { DataserviceService } from '../service/dataservice.service';


@Component({
  selector: 'app-piechart',
  templateUrl: './piechart.component.html',
  styleUrls: ['./piechart.component.scss']
})
export class PiechartComponent implements OnInit, OnDestroy {

  resultData = [];
  chart: any;
  chartOptions: any;

  openCounter = 0;
  closeCounter = 0;
  timerId: any;
  constructor(private dataService: DataserviceService) { }

  ngOnInit() {


    this.getPieData();

    this.timerId = setInterval(() => {
      this.getPieData();
    }, 60000);
  }

  drawPieChart(data) {
    let that = this;
    this.chart = new Chart({
      chart: {
        type: 'pie',
        height: 300
      },

      title: {
        text: 'Ticket Ratio'
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: false
          },
          showInLegend: true,
        }
      },
      colors: ['#ff4d4d', 'rgb(144, 238, 126)'],
      legend: {
        align: 'right',
        verticalAlign: 'top',
        layout: 'vertical',
        x: -50,
        y: 80,
        itemStyle: {
          fontSize : '15'
        }
      },

      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      series: data
    });

  }

  ngOnDestroy() {
    if (this.timerId) {
      clearInterval(this.timerId);
    }
  }

  getPieData() {
    this.dataService.reasonData().subscribe(resultCount => {
      this.resultData.push(resultCount);
      for (let i = 0; i < this.resultData[0].length; i++) {
        if (this.resultData[0][i].open === true) {
          this.openCounter++;
        } else if (this.resultData[0][i].open === false) {
          this.closeCounter++;
        }
      }
      let data = [{
        name: 'Ticket status',
        colorByPoint: true,
        data: [{
          name: 'Open',
          y: this.openCounter,
          sliced: true,
          selected: true
        }, {
          name: 'Closed',
          y: this.closeCounter
        }]
      }];
      this.drawPieChart(data);
    })
  }


}

