import { Component, OnInit, ElementRef } from '@angular/core';
import { ROUTES } from '../../sidebar/sidebar.component';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { DataserviceService } from '../../service/dataservice.service';

@Component({
    // moduleId: module.id,
    selector: 'navbar-cmp',
    templateUrl: 'navbar.component.html',
    styleUrls: ['./navbar.component.css']
})

export class NavbarComponent implements OnInit {
    private listTitles: any[];
    location: Location;
    private toggleButton: any;
    private sidebarVisible: boolean;
    showStatus: boolean = true;
    appName: string;
    timerId: any;
    ticketCount = [];
    notificationCount = 0;
    healthStatusValue: boolean = false;
    prevCount = 0;
    problems = [];
    constructor(location: Location, private element: ElementRef, public healthStatus: DataserviceService) {
        this.location = location;
        this.sidebarVisible = false;
        this.appName = localStorage.getItem('appName');
    }

    ngOnInit() {
        this.listTitles = ROUTES.filter(listTitle => listTitle);
        const navbar: HTMLElement = this.element.nativeElement;
        this.toggleButton = navbar.getElementsByClassName('navbar-toggle')[0];
        //Date: 8 Nov
        this.healthStatus.healthStatus().subscribe(response => {
            console.log('health...', response);
            if (response != null) {
                if (response['status'] == 'UP') {
                    console.log('up running');
                    this.healthStatusValue = true;
                }
                else {
                    this.healthStatusValue = false;
                }
            }
            else {
                this.healthStatusValue = false;
            }
            console.log("health", this.healthStatusValue);
        });


        this.getNewTicket();

        this.timerId = setInterval(() => {
            this.getNewTicket();
        }, 60000);
    }


    getNewTicket() {
        this.ticketCount = [];
        this.notificationCount = 0;
        this.problems = [];
        this.healthStatus.reasonData().subscribe(count => {
            this.ticketCount.push(count);
            console.log('status...', this.ticketCount);
            for (let i = 0; i < this.ticketCount[0].length; i++) {
                if (this.ticketCount[0][i].open === true && this.ticketCount[0][i].severity === 'ERROR') {
                    this.notificationCount++;
                    console.log('logMessage',this.ticketCount[0][i].logMessage);
                    this.problems.push((this.ticketCount[0][i].logMessage).replace('\n',''));
                }
            }
            console.log('problem statement', this.problems);

        });

    }


    sidebarOpen() {
        const toggleButton = this.toggleButton;
        const body = document.getElementsByTagName('body')[0];
        setTimeout(function () {
            toggleButton.classList.add('toggled');
        }, 500);
        body.classList.add('nav-open');

        this.sidebarVisible = true;
    };
    sidebarClose() {
        const body = document.getElementsByTagName('body')[0];
        this.toggleButton.classList.remove('toggled');
        this.sidebarVisible = false;
        body.classList.remove('nav-open');
    };
    sidebarToggle() {
        // const toggleButton = this.toggleButton;
        // const body = document.getElementsByTagName('body')[0];
        if (this.sidebarVisible === false) {
            this.sidebarOpen();
        } else {
            this.sidebarClose();
        }
    };

    getTitle() {
        var titlee = this.location.prepareExternalUrl(this.location.path());
        if (titlee.charAt(0) === '#') {
            titlee = titlee.slice(1);
        }

        for (var item = 0; item < this.listTitles.length; item++) {
            if (this.listTitles[item].path === titlee) {
                return this.listTitles[item].title;
            }
        }
        return 'Dashboard';
    }


}
