import { Component, OnInit, OnDestroy } from '@angular/core';
import { Chart } from 'angular-highcharts';
import * as Highcharts from 'highcharts';
import { DataserviceService } from '../service/dataservice.service';

@Component({
  selector: 'app-stackedcolumnchart',
  templateUrl: './stackedcolumnchart.component.html',
  styleUrls: ['./stackedcolumnchart.component.scss']
})
export class StackedcolumnchartComponent implements OnInit, OnDestroy {
  chart: any;
  maindata = [];
  category = [];
  countData = [];
  dummyManindata = [];
  responseDataList = [];
  timerId: any;

  constructor(public severityCount: DataserviceService) { }

  ngOnInit() {
    //  Service for severity Logs Count: Date: 8 Nov

    this.getStackdata();
    this.timerId = setInterval(() => {
      this.getStackdata();
    }, 60000);
  }

  drawStackedChart(data) {
    let that = this;
    this.chart = new Chart({
      chart: {
        type: 'column',
        height: 300
      },
      credits: {
        enabled: false
      },
      exporting: {
        enabled: false
      },
      title: {
        text: 'Severity Log Stats',
        // useHTML: true
      },
      xAxis: {
        categories: this.category,
        type: 'datetime',
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Log Count'
        },

      },
      colors: ['#95ceff', 'orange', '#90ee7e', 'blue', 'grey', 'yellow'],
      tooltip: {
        headerFormat: '<b>{point.x}</b><br/>',
        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          dataLabels: {
            enabled: false
          }
        }
      },
      series: data
    });
  }

  ngOnDestroy() {
    if (this.timerId) {
      clearInterval(this.timerId);
    }
  }

  getStackdata() {
    this.severityCount.severityCountData().subscribe(response => {
      this.responseDataList.push(response);
      function formatDate(date) {
        var monthNames = [
          "Jan", "Feb", "Mar",
          "Apr", "May", "Jun", "Jul",
          "Aug", "Sep", "Oct",
          "Nov", "Dec"
        ];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        return day + ' ' + monthNames[monthIndex] + ' ' + year;
      }
      this.category = [];
      for (let i = 0; i < this.responseDataList[0].length; i++) {
        let date = new Date(this.responseDataList[0][i]['date'])
        console.log(formatDate(date), "hello")
        this.category.push(formatDate(date))
      }
      this.maindata = [];
      for (let i = 0; i < 1; i++) {
        for (let j = 0; j < this.responseDataList[0][i]['severity'].length; j++) {
          let name = this.responseDataList[0][i]['severity'][j]
          this.countData = [];
          for (let k = 0; k < this.responseDataList[0].length; k++) {
            this.countData.push(this.responseDataList[0][k]['count'][j])
          }
          this.maindata.push({
            'name': name,
            'data': this.countData
          })
          console.log('countdata', this.maindata)
          this.drawStackedChart(this.maindata);
        }
      }
    })
  }
}
