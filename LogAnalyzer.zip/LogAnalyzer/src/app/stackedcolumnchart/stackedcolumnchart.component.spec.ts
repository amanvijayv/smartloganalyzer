import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StackedcolumnchartComponent } from './stackedcolumnchart.component';

describe('StackedcolumnchartComponent', () => {
  let component: StackedcolumnchartComponent;
  let fixture: ComponentFixture<StackedcolumnchartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StackedcolumnchartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StackedcolumnchartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
