import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort, MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { DataserviceService } from '../service/dataservice.service';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  sourceData = [];
  reasons: any;
  reasonList = [];
  close = [];
  closeTicket = [];
  id: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;


  dataSource = new MatTableDataSource<TicketElement>();
  displayedColumns: string[] = ['ticketId', 'date', 'time',
    'severity', 'reason',
    'solution', 'action'];

  constructor(public ticketSer: DataserviceService, public toastr: ToastrService) { }

  ngOnInit() {
    this.reasonList = [];
    console.log('data...');
    this.ticketSer.reasonData().subscribe(response => {
      console.log('jsonstringify..', JSON.parse(JSON.stringify(response).replace('\\n', '')));
      this.reasonList.push(response);
      this.sourceData = [];
      for (let i = 0; i < this.reasonList[0].length; i++) {
        if (this.reasonList[0][i].severity === 'ERROR') {
          let obj = {
            'ticketId': this.reasonList[0][i].ticketId,
            'severity': this.reasonList[0][i].severity,
            'date': this.reasonList[0][i].date,
            'logMessage': (this.reasonList[0][i].logMessage).replace('\n', ''),
            'solution': this.reasonList[0][i].solution,
            'appName': this.reasonList[0][i].appName,
            'open': this.reasonList[0][i].open
          }
          this.closeTicket.push(obj['open'])
          console.log('obj', obj);
          this.sourceData.push(obj);
        }
      }
      console.log('closebutton', this.closeTicket)
      this.dataSource = new MatTableDataSource<TicketElement>(this.sourceData);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  onClosingticket(closeData, index) {
    let closeTicketObj = {
      'ticketId': closeData.ticketId,
      'severity': closeData.severity,
      'date': closeData.date,
      'logMessage': closeData.logMessage,
      'solution': closeData.solution,
      'appName': closeData.appName,
      'open': false
    }

    this.ticketSer.updateTicket(closeTicketObj).subscribe(response => {
      console.log('close...', response, typeof (response));
      if (response === true) {
        this.toastr.success('Ticket Close Successfully!!!');
        this.ngOnInit();
      }
    })
  }

}
export interface TicketElement {
  ticketId: number;
  date: string;
  time: string;
  severity: string;
  reason: string;
  solution: string;
}
