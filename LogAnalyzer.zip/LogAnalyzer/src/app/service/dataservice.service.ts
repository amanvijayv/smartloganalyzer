import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {

  logsCountURL = 'http://ec2-54-152-137-117.compute-1.amazonaws.com:8081/getalllogsCount';
  healthStatusURL = 'http://ec2-54-152-137-117.compute-1.amazonaws.com:8081/actuator/health';
  ticketURL = 'http://ec2-54-152-137-117.compute-1.amazonaws.com:8081/getTickets';
  updateTicketURL = 'http://ec2-54-152-137-117.compute-1.amazonaws.com:8081/updateTicket';


  constructor(private http: HttpClient) { }

  reasonData() {
    return this.http.get(this.ticketURL);
  }

  severityCountData() {
    console.log("Service");
    return this.http.get(this.logsCountURL);
  }

  healthStatus() {
    let headers = new HttpHeaders();
    headers.append("Access-Control-Allow-Methods", "GET, POST"),
    headers.append("Access-Control-Allow-Origin","*");
    return this.http.get(this.healthStatusURL, { headers: headers });
  }

  updateTicket(dataObj) {
    return this.http.post(this.updateTicketURL, dataObj);
  }
}
